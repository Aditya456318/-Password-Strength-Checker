function checkStrength() {
  const password = document.getElementById("password").value;
  const bar = document.getElementById("bar");
  const text = document.getElementById("strengthText");
  const suggestions = document.getElementById("suggestions");

  let strength = 0;
  let suggestionList = [];

  if (password.length >= 8) strength++; else suggestionList.push("Use at least 8 characters");
  if (/[A-Z]/.test(password)) strength++; else suggestionList.push("Add uppercase letters");
  if (/[a-z]/.test(password)) strength++; else suggestionList.push("Add lowercase letters");
  if (/[0-9]/.test(password)) strength++; else suggestionList.push("Include numbers");
  if (/[@$!%*#?&]/.test(password)) strength++; else suggestionList.push("Include special characters");

  // Strength Bar & Text
  if (password.length === 0) {
    bar.style.width = "0%";
    bar.style.backgroundColor = "#333";
    text.textContent = "";
    suggestions.innerHTML = "";
    return;
  }

  if (strength <= 2) {
    bar.style.width = "33%";
    bar.style.backgroundColor = "red";
    text.textContent = "Weak Password ❌";
  } else if (strength === 3 || strength === 4) {
    bar.style.width = "66%";
    bar.style.backgroundColor = "orange";
    text.textContent = "Moderate Password ⚠️";
  } else {
    bar.style.width = "100%";
    bar.style.backgroundColor = "limegreen";
    text.textContent = "Strong Password ✅";
  }

  // Show Suggestions
  suggestions.innerHTML = "";
  suggestionList.forEach((s) => {
    const li = document.createElement("li");
    li.textContent = s;
    suggestions.appendChild(li);
  });
}

// Toggle password visibility
function togglePassword() {
  const password = document.getElementById("password");
  password.type = password.type === "password" ? "text" : "password";
}